<?php return array('dependencies' => array(), 'version' => '983ae7297d5994ab5aaf');
